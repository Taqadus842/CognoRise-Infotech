package studentCourseRegistrationSystem;

import java.util.ArrayList;
import java.util.List;

public class Student {
    private String studentID;
    private String name;
    private List<Course> registeredCourses;

    // Constructor
    public Student(String studentID, String name) {
        this.studentID = studentID;
        this.name = name;
        this.registeredCourses = new ArrayList<>();
    }

    // Getters
    public String getStudentID() {
        return studentID;
    }

    public String getName() {
        return name;
    }

    public List<Course> getRegisteredCourses() {
        return registeredCourses;
    }

    // Register for a course
    public boolean registerCourse(Course course) {
        if (registeredCourses.contains(course)) {
            System.out.println("Already registered for the course: " + course.getTitle());
            return false;
        }
        if (course.registerStudent()) {
            registeredCourses.add(course);
            System.out.println("Successfully registered for the course: " + course.getTitle());
            return true;
        } else {
            System.out.println("Course is full: " + course.getTitle());
            return false;
        }
    }

    // Drop a course
    public void dropCourse(Course course) {
        if (registeredCourses.remove(course)) {
            course.deRegisterStudent();
            System.out.println("Successfully dropped the course: " + course.getTitle());
        } else {
            System.out.println("You are not registered for this course: " + course.getTitle());
        }
    }
}
