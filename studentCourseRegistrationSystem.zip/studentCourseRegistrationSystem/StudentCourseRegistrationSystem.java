package studentCourseRegistrationSystem;

import java.util.*;

public class StudentCourseRegistrationSystem {

    private static Map<String, Course> courseDatabase = new HashMap<>();
    private static Map<String, Student> studentDatabase = new HashMap<>();

    public static void main(String[] args) {
        // Initialize courses
        courseDatabase.put("CS101", new Course("CS101", "Intro to Programming", "Basics of programming.", 50));
        courseDatabase.put("CS102", new Course("CS102", "Data Structures", "Learn data structures and algorithms.", 40));
        courseDatabase.put("CS103", new Course("CS103", "Operating Systems", "Understand OS concepts.", 30));

        // Initialize students
        studentDatabase.put("S001", new Student("S001", "Ali"));
        studentDatabase.put("S002", new Student("S002", "Khan"));
        studentDatabase.put("S003", new Student("S003", "Bilal"));

        // Main menu
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("\n=== Student Course Registration System ===");
            System.out.println("1. View Courses");
            System.out.println("2. Register for a Course");
            System.out.println("3. Drop a Course");
            System.out.println("4. View Registered Courses");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    displayCourses();
                    break;
                case 2:
                    registerForCourse(scanner);
                    break;
                case 3:
                    dropCourse(scanner);
                    break;
                case 4:
                    viewRegisteredCourses(scanner);
                    break;
                case 5:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    // Display available courses
    private static void displayCourses() {
        System.out.println("\nAvailable Courses:");
        for (Course course : courseDatabase.values()) {
            System.out.printf("Course Code: %s, Title: %s, Description: %s, Capacity: %d, Registered: %d\n",
                    course.getCourseCode(), course.getTitle(), course.getDescription(),
                    course.getCapacity(), course.getRegisteredCount());
        }
    }

    // Register for a course
    private static void registerForCourse(Scanner scanner) {
        System.out.print("\nEnter your Student ID: ");
        String studentID = scanner.next();
        Student student = studentDatabase.get(studentID);

        if (student == null) {
            System.out.println("Invalid Student ID.");
            return;
        }

        System.out.print("Enter Course Code to register: ");
        String courseCode = scanner.next();
        Course course = courseDatabase.get(courseCode);

        if (course == null) {
            System.out.println("Invalid Course Code.");
            return;
        }

        if (student.registerCourse(course)) {
            System.out.println("Successfully registered for the course.");
        }
    }

    // Drop a course
    private static void dropCourse(Scanner scanner) {
        System.out.print("\nEnter your Student ID: ");
        String studentID = scanner.next();
        Student student = studentDatabase.get(studentID);

        if (student == null) {
            System.out.println("Invalid Student ID.");
            return;
        }

        System.out.print("Enter Course Code to drop: ");
        String courseCode = scanner.next();
        Course course = courseDatabase.get(courseCode);

        if (course == null) {
            System.out.println("Invalid Course Code.");
            return;
        }

        student.dropCourse(course);
    }

    // View registered courses for a student
    private static void viewRegisteredCourses(Scanner scanner) {
        System.out.print("\nEnter your Student ID: ");
        String studentID = scanner.next();
        Student student = studentDatabase.get(studentID);

        if (student == null) {
            System.out.println("Invalid Student ID.");
            return;
        }

        List<Course> registeredCourses = student.getRegisteredCourses();
        if (registeredCourses.isEmpty()) {
            System.out.println("No courses registered.");
        } else {
            System.out.println("Registered Courses:");
            for (Course course : registeredCourses) {
                System.out.printf("Course Code: %s, Title: %s\n", course.getCourseCode(), course.getTitle());
            }
        }
    }
}
