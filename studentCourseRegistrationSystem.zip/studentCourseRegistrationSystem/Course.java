package studentCourseRegistrationSystem;

public class Course {
    private String courseCode;
    private String title;
    private String description;
    private int capacity;
    private int registeredCount;

    // Constructor with all parameters
    public Course(String courseCode, String title, String description, int capacity, int registeredCount) {
        this.courseCode = courseCode;
        this.title = title;
        this.description = description;
        this.capacity = capacity;
        this.registeredCount = registeredCount;
    }

    // Constructor with default registeredCount
    public Course(String courseCode, String title, String description, int capacity) {
        this(courseCode, title, description, capacity, 0); // Calls the main constructor
    }

    public String getCourseCode() {
        return courseCode;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public int getCapacity() {
        return capacity;
    }

    public int getRegisteredCount() {
        return registeredCount;
    }

    public boolean registerStudent() {
        if (registeredCount < capacity) {
            registeredCount++;
            return true;
        } else return false;
    }

    public void deRegisterStudent() {
        if (registeredCount > 0) {
            registeredCount--;
        }
    }
}
